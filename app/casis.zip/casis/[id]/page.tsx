// app/casis/[id]/page.tsx

import { notFound } from 'next/navigation';
import { createClient } from '@/utils/supabase/server';
import { CasisDetailClient } from './CasisDetailClient';
import { deleteInspection } from '@/app/casis/actions';
import { SupabaseClient } from '@supabase/supabase-js'; // <-- Impor SupabaseClient untuk tipe

export const dynamic = 'force-dynamic';

// ===================================================================
// LANGKAH 1: DEFINISIKAN SEMUA TIPE DATA YANG DIPERLUKAN
// ===================================================================

type Props = {
  params: { id: string };
};

// Tipe untuk data dari tabel 'inspection_items'
type InspectionItem = {
  id: string;
  name: string;
  standard: string | null;
  category: string;
  parent_id: string | null;
  page_title: string | null;
};

// Tipe untuk data dari tabel 'inspection_results'
type InspectionResult = {
  id: string;
  item_id: string;
  kondisi: string;
  keterangan: string | null;
  problem_photo_url: string | null;
};

// Tipe untuk data gabungan yang akan ditampilkan
type ItemWithResult = InspectionItem & {
  resultId: string | null;
  kondisi: string;
  keterangan: string | null;
  problem_photo_url: string | null;
};

// Tipe untuk baris data di tabel tampilan (sama seperti tipe Row Anda)
type Row = {
  id: string;
  name:string;
  standard: string | null;
  resultId: string | null;
  kondisi: string;
  keterangan: string | null;
  problem_photo_url: string | null;
};

// Tipe untuk data parent
type ParentItem = {
    id: string;
    name: string;
};


export default async function Page({ params }: Props) {
  const inspectionId = params.id;
  // ===================================================================
  // LANGKAH 2: KEMBALIKAN `await`
  // ===================================================================
  const supabase = createClient();

  const { data, error: headerError } = await supabase
    .from('inspections')
    .select(
      `*, chassis!inspections_chassis_id_fkey(chassis_code, feet), profiles!fk_inspector(name)`
    )
    .eq('id', inspectionId)
    .single();

  if (headerError || !data || !data.chassis) return notFound();

  const inspectionHeader = data;
  const feet = data.chassis.feet;
  const searchPattern = `%(C${feet})`;

  // ===================================================================
  // LANGKAH 3: TERAPKAN TIPE PADA SETIAP PENGAMBILAN DATA
  // ===================================================================

  const { data: allMasterItems } = await supabase
    .from('inspection_items')
    .select('*')
    .eq('category', 'Chassis')
    .ilike('name', searchPattern);

  const { data: inspectionResults } = await supabase
    .from('inspection_results')
    .select('id, item_id, kondisi, keterangan, problem_photo_url')
    .eq('inspection_id', inspectionId);

  // Beri tipe pada parameter callback untuk Map
  const resultsMap = new Map(
    (inspectionResults || []).map((result: InspectionResult) => [
      result.item_id,
      {
        id: result.id,
        kondisi: result.kondisi,
        keterangan: result.keterangan,
        problem_photo_url: result.problem_photo_url,
      },
    ])
  );

  // Beri tipe pada parameter callback untuk map dan pastikan return type cocok
  const itemsWithResults: ItemWithResult[] = (allMasterItems || []).map((item: InspectionItem) => {
    const result = resultsMap.get(item.id);
    return {
      ...item,
      resultId: result?.id || null,
      kondisi: result?.kondisi || 'Belum Diperiksa',
      keterangan: result?.keterangan || '-',
      problem_photo_url: result?.problem_photo_url || null,
    };
  });

  const groups: Record<string, { parentName: string; rows: Row[] }[]> = {};
  const parentNameMap = new Map<string, string>();
  const parentIds = [
    ...new Set(itemsWithResults.map((item) => item.parent_id).filter(Boolean)),
  ];

  if (parentIds.length > 0) {
    const { data: parents } = await supabase
      .from('inspection_items')
      .select('id, name')
      .in('id', parentIds as string[]);
    // Beri tipe pada parameter callback untuk forEach
    (parents || []).forEach((p: ParentItem) => parentNameMap.set(p.id, p.name));
  }

  // Beri tipe pada item di dalam loop
  for (const item of itemsWithResults) {
    const pageTitle = item.page_title || 'Lainnya';
    if (!groups[pageTitle]) groups[pageTitle] = [];

    const parentName = item.parent_id
      ? parentNameMap.get(item.parent_id) || 'Sub-grup'
      : item.name;

    let subGroup = groups[pageTitle].find((g) => g.parentName === parentName);
    if (!subGroup) {
      subGroup = { parentName, rows: [] };
      groups[pageTitle].push(subGroup);
    }

    const rowData: Row = {
      id: item.id,
      name: item.name,
      standard: item.standard,
      resultId: item.resultId,
      kondisi: item.kondisi,
      keterangan: item.keterangan,
      problem_photo_url: item.problem_photo_url,
    };

    if (item.parent_id) {
      subGroup.rows.push(rowData);
    } else {
      if (subGroup.rows.length === 0) subGroup.rows.push(rowData);
    }
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">
        Detail Pemeriksaan Casis {inspectionHeader.chassis.chassis_code} (
        {feet} Feet)
      </h1>
      <CasisDetailClient
        inspectionHeader={inspectionHeader}
        groups={groups}
        deleteAction={deleteInspection}
      />
    </div>
  );
}