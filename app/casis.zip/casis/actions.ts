'use server';

import { createClient } from '@/utils/supabase/server';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  Table,
  TableRow,
  TableCell,
  WidthType,
  HeadingLevel,
} from 'docx';

// Tipe data untuk response form
export type FormState = { message: string; success: boolean, error?: boolean };


// =================================================================
// FUNGSI UNTUK AUTENTIKASI
// =================================================================
export async function login(formData: FormData) {
  const email = formData.get('email') as string;
  const password = formData.get('password') as string;
  const supabase = createClient();

  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return redirect('/login?message=Email atau password salah.');
  return redirect('/');
}

export async function signup(formData: FormData) {
  const email = formData.get('email') as string;
  const password = formData.get('password') as string;
  const confirmPassword = formData.get('confirm_password') as string;
  const supabase = createClient();

  if (password !== confirmPassword) return redirect('/signup?message=Password tidak cocok.');

  const { error } = await supabase.auth.signUp({ email, password });
  if (error) return redirect('/signup?message=Gagal membuat akun.');
  return redirect('/login?message=Pendaftaran berhasil! Silakan cek email Anda untuk verifikasi.');
}


// =================================================================
// FUNGSI UNTUK CASIS
// =================================================================
export async function addCasis(prevState: FormState, formData: FormData): Promise<FormState> {
  const supabase = createClient();
  const casisCode = formData.get('casis_code') as string;
  const type = formData.get('type') as string;
  const feet = formData.get('feet') as string;

  if (!casisCode || !type || !feet) {
    return { message: 'Semua field wajib diisi.', success: false, error: true };
  }

  const { error } = await supabase
    .from('chassis')
    .insert({ chassis_code: casisCode, type: type, feet: Number(feet) });

  if (error) {
    console.error('Add Casis Error:', error);
    return { message: `Gagal menyimpan: ${error.message}`, success: false, error: true };
  }

  revalidatePath('/casis');
  return { message: 'Casis baru berhasil ditambahkan!', success: true };
}

// FIX: Menambahkan fungsi untuk generate dokumen Word
export async function generateCasisWordDoc(inspectionId: string) {
  const supabase = createClient();

  const { data: inspectionHeader } = await supabase
    .from('inspections')
    .select(`*, chassis!inner(chassis_code), profiles!inner(name)`)
    .eq('id', inspectionId)
    .single();
  
  if (!inspectionHeader) throw new Error('Data inspeksi tidak ditemukan');

  const { data: allMasterItems } = await supabase.from('inspection_items').select('*').eq('category', 'Chassis');
  const { data: inspectionResults } = await supabase.from('inspection_results').select('*').eq('inspection_id', inspectionId);
  
  const resultsMap = new Map(inspectionResults?.map(r => [r.item_id, r]));
  const itemsWithResults = (allMasterItems || []).map(item => ({
    ...item,
    result: resultsMap.get(item.id)
  }));

  const groups: Record<string, any[]> = {};
  itemsWithResults.forEach(item => {
    const pageTitle = item.page_title || 'Lainnya';
    if (!groups[pageTitle]) groups[pageTitle] = [];
    groups[pageTitle].push(item);
  });

  const doc = new Document({
    sections: [{
      properties: {},
      children: [
        new Paragraph({ text: "Informasi Pemeriksaan", heading: HeadingLevel.HEADING_1 }),
        new Paragraph({ children: [ new TextRun({ text: "Nama Pemeriksa: ", bold: true }), new TextRun(inspectionHeader.profiles.name || 'N/A'), ] }),
        new Paragraph({ children: [ new TextRun({ text: "Nomor Casis: ", bold: true }), new TextRun(inspectionHeader.chassis.chassis_code || 'N/A'), ] }),
        new Paragraph({ children: [ new TextRun({ text: "Tanggal: ", bold: true }), new TextRun(new Date(inspectionHeader.tanggal).toLocaleDateString('id-ID')), ] }),
        new Paragraph({ children: [ new TextRun({ text: "Catatan: ", bold: true }), new TextRun(inspectionHeader.catatan || '-'), ] }),
        new Paragraph(""), 
        
        ...Object.entries(groups).flatMap(([pageTitle, items]) => [
          new Paragraph({ text: pageTitle, heading: HeadingLevel.HEADING_2 }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
              new TableRow({ children: [ new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Item", bold: true })] })] }), new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Standard", bold: true })] })] }), new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Kondisi", bold: true })] })] }), new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Keterangan", bold: true })] })] }), ] }),
              ...items.map(item => new TableRow({ children: [ new TableCell({ children: [new Paragraph(item.name)] }), new TableCell({ children: [new Paragraph(item.standard || '-')] }), new TableCell({ children: [new Paragraph(item.result?.kondisi || 'Belum Diperiksa')] }), new TableCell({ children: [new Paragraph(item.result?.keterangan || '-')] }), ] })),
            ],
          }),
          new Paragraph(""),
        ]),
      ],
    }],
  });

  const buffer = await Packer.toBuffer(doc);
  return buffer.toString('base64');
}

// =================================================================
// FUNGSI UNTUK HEAD & STORAGE (DITAMBAHKAN)
// =================================================================
export async function addHead(prevState: FormState, formData: FormData): Promise<FormState> {
    // Implementasi logika untuk menambah head
    return { message: 'Head berhasil ditambahkan', success: true };
}

export async function addStorage(prevState: FormState, formData: FormData): Promise<FormState> {
    // Implementasi logika untuk menambah storage
    return { message: 'Storage berhasil ditambahkan', success: true };
}


// =================================================================
// FUNGSI UMUM
// =================================================================
export async function deleteInspection(formData: FormData) {
  const inspectionId = formData.get('inspectionId') as string;
  const redirectTo = formData.get('redirectTo') as string;

  if (!inspectionId || !redirectTo) return;

  const supabase = createClient();
  const { error } = await supabase.from('inspections').delete().eq('id', inspectionId);

  if (error) {
    console.error('Delete Inspection Error:', error);
    return;
  }

  revalidatePath(redirectTo);
  redirect(redirectTo);
}

export async function upsertInspectionResult(prevState: FormState, formData: FormData): Promise<FormState> {
  const supabase = createClient();
  const data = {
    resultId: formData.get('resultId') as string,
    inspectionId: formData.get('inspectionId') as string,
    itemId: formData.get('itemId') as string,
    kondisi: formData.get('kondisi') as string,
    keterangan: formData.get('keterangan') as string,
    pathname: formData.get('pathname') as string,
  };

  if (!data.kondisi || !data.itemId || !data.inspectionId) {
    return { message: 'Data tidak lengkap.', success: false };
  }

  if (data.resultId && data.resultId !== 'undefined' && data.resultId !== 'null') {
    const { error } = await supabase
      .from('inspection_results')
      .update({ kondisi: data.kondisi, keterangan: data.keterangan })
      .eq('id', data.resultId);
    if (error) return { message: `Gagal mengupdate: ${error.message}`, success: false };
  } else {
    const { error } = await supabase.from('inspection_results').insert({
      inspection_id: data.inspectionId,
      item_id: data.itemId,
      kondisi: data.kondisi,
      keterangan: data.keterangan,
    });
    if (error) return { message: `Gagal menyimpan: ${error.message}`, success: false };
  }

  revalidatePath(data.pathname);
  return { message: 'Data berhasil disimpan!', success: true };
}

export async function getRecapData(period: 'daily' | 'weekly' | 'monthly' | 'yearly') {
  const supabase = createClient();
  const now = new Date();
  let startDate: Date;

  switch (period) {
    case 'daily': startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate()); break;
    case 'weekly': startDate = new Date(now.setDate(now.getDate() - now.getDay())); startDate.setHours(0, 0, 0, 0); break;
    case 'monthly': startDate = new Date(now.getFullYear(), now.getMonth(), 1); break;
    case 'yearly': startDate = new Date(now.getFullYear(), 0, 1); break;
    default: throw new Error('Invalid period specified');
  }

  const { data, error } = await supabase
    .from('inspections')
    .select(`id, tanggal, chassis(chassis_code), heads(head_code), storages(storage_code), inspection_results(kondisi, keterangan, inspection_items(name, standard))`)
    .gte('tanggal', startDate.toISOString());

  if (error) {
    console.error('Error fetching recap data:', error);
    return [];
  }

  const formattedData = data.flatMap(inspection => {
    const assetCode = inspection.chassis[0]?.chassis_code || inspection.heads[0]?.head_code || inspection.storages[0]?.storage_code || 'N/A';
    return inspection.inspection_results.map(result => {
      const itemDetails = Array.isArray(result.inspection_items) ? result.inspection_items[0] : result.inspection_items;
      return {
        'Kode Aset': assetCode,
        'Tanggal Inspeksi': new Date(inspection.tanggal).toLocaleDateString('id-ID'),
        'Item Diperiksa': itemDetails?.name || 'N/A',
        'Standard': itemDetails?.standard || '-',
        'Kondisi': result.kondisi,
        'Keterangan': result.keterangan,
      };
    });
  });

  return formattedData;
}
