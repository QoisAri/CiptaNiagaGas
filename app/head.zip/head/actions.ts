'use server'

import { createClient } from '../../utils/supabase/server';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';

export type FormState = {
  message: string;
};

/**
 * Mengambil ringkasan data inspeksi untuk semua 'Head'.
 */
export async function getAllHeadInspections() {
  const supabase = await createClient();
  const { data: inspections, error } = await supabase
    .from('inspections')
    .select(`id, tanggal, heads(head_code, feet), profiles(name), inspection_results(kondisi)`)
    .not('head_id', 'is', null);

  if (error) {
    console.error('Error fetching head inspections:', error);
    return [];
  }

  return inspections.map(item => {
    const headData = Array.isArray(item.heads) ? item.heads[0] : item.heads;
    const profileData = Array.isArray(item.profiles) ? item.profiles[0] : item.profiles;
    return {
      id: item.id,
      code: headData?.head_code,
      tanggal: new Date(item.tanggal).toLocaleDateString('id-ID'),
      pemeriksa: profileData?.name || 'N/A',
      type: headData?.feet,
      hasError: item.inspection_results.some((res: any) => res.kondisi?.toLowerCase() !== 'baik'),
    };
  });
}

/**
 * Menambah data master Head baru dari modal.
 */
export async function addHead(prevState: FormState, formData: FormData): Promise<FormState> {
  const supabase = await createClient();
  const headCode = formData.get('head_code') as string;
  const type = formData.get('type') as string;
  const feet = formData.get('feet') as string;

  if (!headCode || !feet) {
    return { message: 'Head Code dan Ukuran Feet wajib diisi.' };
  }

  const { error } = await supabase.from('heads').insert({
    head_code: headCode,
    type: type,
    feet: parseInt(feet, 10),
  });

  if (error) {
    console.error('Error adding head:', error);
    return { message: 'Gagal menyimpan data.' };
  }
  
  revalidatePath('/head');
  return { message: 'Data berhasil ditambahkan!' };
}

/**
 * Mengambil dan MENGELOMPOKKAN data detail untuk SATU sesi inspeksi.
 */
// Di dalam file: app/head/actions.ts

export async function getInspectionDetailsById(inspectionId: string) {
  const supabase = await createClient();
  
  const { data, error } = await supabase
    .from('inspections')
    .select(`
      tanggal, catatan,
      profiles(name),
      heads(head_code, type, feet),
      inspection_results(id, kondisi, keterangan, inspection_items(name, category))
    `)
    .eq('id', inspectionId)
    .single();

  if (error) {
    console.error('Error fetching head details:', error);
    return null;
  }
  return data; // HANYA KEMBALIKAN DATA MENTAH
}

/**
 * Menghapus satu sesi inspeksi berdasarkan ID-nya.
 */
export async function deleteInspection(inspectionId: string) {
  'use server'
  const supabase = await createClient();
  const { error } = await supabase.from('inspections').delete().eq('id', inspectionId);

  if (error) {
    console.error('Error deleting inspection:', error);
    return;
  }
  
  revalidatePath('/head');
  redirect('/head');
}
export async function getRecapData(period: 'daily' | 'weekly' | 'monthly' | 'yearly') {
  const supabase = await createClient();
  const today = new Date();
  let startDate = new Date();

  switch (period) {
    case 'daily': startDate.setHours(0, 0, 0, 0); break;
    case 'weekly':
      const firstDayOfWeek = today.getDate() - today.getDay();
      startDate = new Date(today.setDate(firstDayOfWeek));
      startDate.setHours(0, 0, 0, 0);
      break;
    case 'monthly': startDate = new Date(today.getFullYear(), today.getMonth(), 1); break;
    case 'yearly': startDate = new Date(today.getFullYear(), 0, 1); break;
  }
  const formattedStartDate = startDate.toISOString().split('T')[0];

  const { data: inspections, error } = await supabase
    .from('inspections')
    .select(`tanggal, profiles(name), heads(head_code), chassis(chassis_code), storages(storage_code), inspection_results(kondisi, keterangan, inspection_items(name, parent_id))`)
    .gte('tanggal', formattedStartDate)
    .lte('tanggal', today.toISOString().split('T')[0])
    .order('tanggal', { ascending: false });

  if (error || !inspections) {
    return [];
  }

  const allResults = inspections.flatMap((i: any) => i.inspection_results);
  const parentIds = allResults
    .map((r: any) => (Array.isArray(r.inspection_items) ? r.inspection_items[0]?.parent_id : r.inspection_items?.parent_id))
    .filter(Boolean);
  
  const { data: parents } = await supabase.from('inspection_items').select('id, name').in('id', [...new Set(parentIds)]);
  const parentMap = new Map(parents?.map(p => [p.id, p.name]) || []);

  return inspections.flatMap(inspection => {
    const profileData = Array.isArray(inspection.profiles) ? inspection.profiles[0] : inspection.profiles;
    const headData = Array.isArray(inspection.heads) ? inspection.heads[0] : inspection.heads;
    const chassisData = Array.isArray(inspection.chassis) ? inspection.chassis[0] : inspection.chassis;
    const storageData = Array.isArray(inspection.storages) ? inspection.storages[0] : inspection.storages;
    
    return inspection.inspection_results.map(result => {
      const itemData = Array.isArray(result.inspection_items) ? result.inspection_items[0] : result.inspection_items;
      return {
        'Tanggal': new Date(inspection.tanggal).toLocaleDateString('id-ID'),
        'Pemeriksa': profileData?.name || 'N/A',
        'Tipe Aset': headData ? 'Head' : (chassisData ? 'Chassis' : 'Storage'),
        'Kode Aset': headData?.head_code || chassisData?.chassis_code || storageData?.storage_code,
        'Grup Pengecekan': itemData?.parent_id ? parentMap.get(itemData.parent_id) : itemData?.name,
        'Item Dicek': itemData?.name,
        'Kondisi': result.kondisi,
        'Keterangan': result.keterangan
      }
    })
  });
}