// app/head/[id]/page.tsx
import { createServerSupabaseClient } from '@/lib/supabase';
import InspectionDetailClient from './InspectionDetailClient';
import { notFound } from 'next/navigation';
import { HEAD_INSPECTION_CATEGORIES, HEAD_INSPECTION_ITEMS_BY_KEY } from '@/constants/inspectionItems';

// =========================================================
// DEFINISI INTERFACE (PENTING: Pindahkan ke sini)
// =========================================================

// Interface untuk satu baris hasil inspeksi dari tabel 'inspection_results'
interface InspectionResult {
  id: string;
  inspection_id: string;
  item_id: string;
  item_name: string;
  kondisi: string;
  keterangan: string;
  created_at: string;
}

// Interface untuk data header inspeksi (dari tabel 'inspections' yang di-JOIN dengan 'heads')
// Perbaikan: Struktur ini mencerminkan hasil JOIN dari Supabase
interface InspectionHeaderFromDb {
  id: string;
  created_at: string;
  pemeriksa: string;
  heads: { // Ini adalah objek hasil JOIN
    head_code: string;
    feet: number;
  } | null; // Bisa null jika tidak ada data heads yang terkait
}

// Interface untuk data detail inspeksi yang akan dipass ke Client Component
interface InspectionDetailsProps {
  id: string;
  head_code: string;
  tanggal_inspeksi: string;
  pemeriksa: string;
  tipe_feet: number;
}

interface InspectionDetailPageProps {
  params: {
    id: string; // Ini adalah `inspection_id` dari URL
  };
}

export default async function InspectionDetailPage({ params }: InspectionDetailPageProps) {
  const supabase = createServerSupabaseClient();
  const inspectionId = params.id;

  // 1. Ambil data detail inspeksi utama (dari tabel 'inspections' JOIN 'heads')
  const { data: inspectionHeaderData, error: headerError } = await supabase
    .from('inspections')
    .select(`
      id,
      created_at,
      pemeriksa,
      heads (
        head_code,
        feet
      )
    `)
    .eq('id', inspectionId)
    .single();

  if (headerError || !inspectionHeaderData) {
    console.error('Error fetching inspection header:', headerError);
    notFound();
  }

  // Map ke tipe InspectionDetailsProps untuk dipass ke Client Component
  // Perbaikan: Pastikan akses properti 'heads' dan properti di dalamnya aman
  const inspectionHeader: InspectionDetailsProps = {
    id: inspectionHeaderData.id,
    head_code: inspectionHeaderData.heads?.head_code || 'N/A', // Akses .heads?.head_code
    tanggal_inspeksi: inspectionHeaderData.created_at,
    pemeriksa: inspectionHeaderData.pemeriksa || 'N/A',
    tipe_feet: inspectionHeaderData.heads?.feet || 0, // Akses .heads?.feet
  };


  // 2. Ambil semua hasil inspeksi untuk `inspectionId` ini
  const { data: inspectionResultsData, error: resultsError } = await supabase
    .from('inspection_results')
    .select('*')
    .eq('inspection_id', inspectionId)
    .order('created_at', { ascending: true });

  if (resultsError) {
    console.error('Error fetching inspection results:', resultsError);
    return <div>Error loading detail data: {resultsError.message}</div>;
  }

  const results: InspectionResult[] = inspectionResultsData || [];

  return (
    <div className="admin-panel-container">
      <div className="main-content flex-grow">
        <InspectionDetailClient
          inspectionHeader={inspectionHeader}
          inspectionResults={results}
          inspectionCategories={HEAD_INSPECTION_CATEGORIES}
          inspectionItemsByKey={HEAD_INSPECTION_ITEMS_BY_KEY}
        />
      </div>
    </div>
  );
}