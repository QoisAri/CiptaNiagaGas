// app/head/[id]/InspectionDetailClient.tsx
'use client'; // Ini menandakan bahwa komponen ini adalah Client Component

import React from 'react';
// Import interface InspectionItemDefinition dari file constants Anda
import { InspectionItemDefinition } from '@/constants/inspectionItems';

// =========================================================
// 1. Interface untuk Tipe Data
// =========================================================

// Interface untuk satu baris hasil inspeksi dari tabel 'inspection_results'
interface InspectionResult {
  id: string; // UUID dari baris inspection_results
  inspection_id: string; // UUID dari inspeksi utama yang terkait
  item_id: string; // UUID atau key unik dari item inspeksi (bisa sama dengan item_name jika itu key unik)
  item_name: string; // Unique key seperti 'head_per_l1' (penting untuk mapping ke definisi statis)
  kondisi: string;
  keterangan: string;
  created_at: string; // Timestamp ISO string
}

// Interface untuk data header inspeksi (dari tabel 'inspections' yang di-JOIN dengan 'heads')
interface InspectionDetails {
  id: string; // inspections.id (ini adalah inspection_id utama)
  head_code: string; // dari heads.head_code
  tanggal_inspeksi: string; // dari inspections.created_at atau inspections.tanggal
  pemeriksa: string; // dari inspections.pemeriksa
  tipe_feet: number; // dari heads.feet
  // Tambahkan kolom lain dari tabel 'inspections' atau 'heads' jika diperlukan di detail ini
}

// Interface untuk props yang diterima oleh komponen InspectionDetailClient
interface InspectionDetailClientProps {
  inspectionHeader: InspectionDetails;
  inspectionResults: InspectionResult[];
  // Definisi item inspeksi statis yang dikirim dari Server Component (page.tsx)
  inspectionCategories: { [category: string]: InspectionItemDefinition[] };
  inspectionItemsByKey: { [key: string]: InspectionItemDefinition };
}

// =========================================================
// 2. Komponen InspectionDetailClient
// =========================================================
const InspectionDetailClient: React.FC<InspectionDetailClientProps> = ({
  inspectionHeader,
  inspectionResults,
  inspectionCategories, // Props yang berisi kategori dan item definisi
  inspectionItemsByKey, // Props yang berisi map item by key
}) => {
  // Buat Map untuk akses cepat hasil inspeksi berdasarkan 'item_name' (unique key)
  // Ini mempercepat pencarian kondisi/keterangan untuk setiap item yang didefinisikan
  const resultsMap = new Map<string, InspectionResult>();
  inspectionResults.forEach(result => {
    resultsMap.set(result.item_name, result);
  });

  return (
    <div className="p-6">
      {/* Bagian Header Detail Inspeksi */}
      <h1 className="text-2xl font-bold mb-4">Detail Inspeksi Head</h1>
      <div className="bg-white shadow-md rounded-lg p-6 mb-6">
        <h2 className="text-xl font-semibold mb-2">Informasi Inspeksi</h2>
        <p><strong>Head Code:</strong> {inspectionHeader.head_code}</p>
        <p><strong>Tanggal:</strong> {new Date(inspectionHeader.tanggal_inspeksi).toLocaleDateString('id-ID', {
          day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit'
        })}</p>
        <p><strong>Pemeriksa:</strong> {inspectionHeader.pemeriksa}</p>
        <p><strong>Tipe Feet:</strong> {inspectionHeader.tipe_feet}</p>
      </div>

      {/* Bagian Daftar Item Inspeksi yang Dikelompokkan */}
      {/* Looping melalui kategori yang diimpor dari constants/inspectionItems.ts */}
      {Object.entries(inspectionCategories)
        .map(([categoryName, itemsInThisCategory]) => {
          // Filter item-item dalam kategori ini yang memiliki hasil inspeksi di `resultsMap`
          // Ini memastikan hanya item yang benar-benar ada datanya yang ditampilkan
          const itemsWithResults = itemsInThisCategory.filter(itemDef => resultsMap.has(itemDef.key));

          // Jika tidak ada item dengan hasil inspeksi di kategori ini, jangan tampilkan kategori
          if (itemsWithResults.length === 0) {
            return null;
          }

          return (
            <div key={categoryName} className="bg-white shadow-md rounded-lg mb-6 overflow-hidden">
              {/* Nama Kategori */}
              <h2 className="text-xl font-semibold p-4 border-b border-gray-200 bg-gray-50">{categoryName}</h2>
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-white">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      ITEM
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      KONDISI
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      KETERANGAN
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {/* Looping melalui item yang memiliki hasil di kategori ini */}
                  {itemsWithResults.map(itemDef => {
                    const result = resultsMap.get(itemDef.key); // Dapatkan hasil inspeksi untuk item ini

                    return (
                      <tr key={itemDef.key}> {/* Menggunakan itemDef.key sebagai key React karena unik */}
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {itemDef.label} {/* Tampilkan label yang user-friendly dari definisi statis */}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {/* Tampilan kondisi dengan badge warna */}
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            result?.kondisi === 'Baik' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {result?.kondisi || '-'} {/* Tampilkan kondisi atau '-' jika tidak ada */}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {result?.keterangan || '-'} {/* Tampilkan keterangan atau '-' jika tidak ada */}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          );
        })}
    </div>
  );
};

export default InspectionDetailClient;