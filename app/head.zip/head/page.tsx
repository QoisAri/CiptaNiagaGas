// app/head/page.tsx
import { createServerSupabaseClient } from '@/lib/supabase';
import HeadListClient from './HeadListClient'; // Ini akan jadi HeadListSummaryClient
import { notFound } from 'next/navigation';
import { getInspectionIdsByTypeFeet } from '@/constants/inspectionItems'; // Import fungsi filter

// Definisikan tipe data untuk Inspeksi (dari tabel `inspections`)
// Sesuaikan dengan skema tabel `inspections` di Supabase-mu
interface InspectionSummary {
  id: string; // UUID, ini adalah inspection_id
  head_code: string; // Misal: AR-010
  tanggal_inspeksi: string; // timestamp with time zone
  pemeriksa: string; // Nama pemeriksa
  tipe_feet: number; // 10, 20, 40
  // Tambahkan kolom lain yang relevan dari tabel `inspections`
}

// Untuk menerima query parameter dari URL (misal: /head?type=20)
interface HeadPageProps {
  searchParams: {
    type?: string; // Akan menampung '10', '20', '40', atau 'Semua'
  };
}

export default async function HeadSummaryPage({ searchParams }: HeadPageProps) {
  const supabase = createServerSupabaseClient();
  const selectedTypeFeet = searchParams.type;

  let inspections: InspectionSummary[] = [];
  let error: any = null;

  // Bangun query untuk tabel `inspections`
  let query = supabase.from('inspections').select('*'); // Ambil semua kolom untuk ringkasan

  // Terapkan filter berdasarkan `tipe_feet` jika dipilih
  if (selectedTypeFeet && selectedTypeFeet !== 'Semua') {
    query = query.eq('tipe_feet', parseInt(selectedTypeFeet));
  }

  // Urutkan berdasarkan tanggal inspeksi terbaru
  query = query.order('tanggal_inspeksi', { ascending: false });

  const { data, error: fetchError } = await query;
  inspections = data as InspectionSummary[] || [];
  error = fetchError;

  if (error) {
    console.error('Error fetching inspection summaries:', error);
    return <div>Error loading data: {error.message}</div>;
  }

  return (
    <div className="admin-panel-container">
      {/* Sidebar, asumsikan sudah ada di layout.tsx atau diimpor di sini */}
      <div className="main-content flex-grow">
        <HeadListClient initialData={inspections} selectedTypeFeet={selectedTypeFeet} />
      </div>
    </div>
  );
}